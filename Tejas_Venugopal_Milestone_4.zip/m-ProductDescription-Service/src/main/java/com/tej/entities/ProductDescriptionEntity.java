package com.tej.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table (name = "product_description")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDescriptionEntity {
    @Id
    private Integer productId;
    private String productBrand;
    private String productModel;
    private Integer productPrice;

}
