package com.tej.service;

import com.tej.entities.ProductDescriptionEntity;

public interface ProductDescriptionService {

    ProductDescriptionEntity create(ProductDescriptionEntity productDescriptionEntity);
    ProductDescriptionEntity getById(Integer productId);
}
