package com.tej.service;

import com.tej.entities.ProductDescriptionEntity;
import com.tej.repository.ProductDescriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductDescriptionServiceImpl implements ProductDescriptionService{

    @Autowired
    ProductDescriptionRepository productDescriptionRepository;

    @Override
    public ProductDescriptionEntity create(ProductDescriptionEntity productDescriptionEntity) {
        return productDescriptionRepository.save(productDescriptionEntity);
    }

    @Override
    public ProductDescriptionEntity getById(Integer productId) {
        return productDescriptionRepository.findById(productId).orElseThrow( () -> new RuntimeException("No description Found!"));
    }
}
