package com.tej.controller;

import com.tej.entities.ProductDescriptionEntity;
import com.tej.service.ProductDescriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("productdesc")
public class ProductDescriptionController {

    @Autowired
    ProductDescriptionService productDescriptionService;

    @PostMapping
    public ProductDescriptionEntity create(@RequestBody ProductDescriptionEntity productDescriptionEntity) {
        return productDescriptionService.create(productDescriptionEntity);
    }

    @GetMapping("byid/{productId}")
    public ProductDescriptionEntity getById(@PathVariable Integer productId) {
        return  productDescriptionService.getById(productId);
    }
}
