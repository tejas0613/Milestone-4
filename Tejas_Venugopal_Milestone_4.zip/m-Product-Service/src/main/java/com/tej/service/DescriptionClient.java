package com.tej.service;

import com.tej.vo.DescriptionVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "product-description", url = "http://localhost:6161")
public interface DescriptionClient {

    @GetMapping("productdesc/byid/{productId}")
    DescriptionVO getDescription(@PathVariable Integer productId);

}
