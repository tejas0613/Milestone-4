package com.tej.service;

import com.tej.entities.ProductEntity;
import com.tej.repository.ProductRepository;
import com.tej.vo.DescriptionVO;
import com.tej.vo.ProductAndDescriptionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private DescriptionClient descriptionClient;

    @Override
    public ProductEntity create(ProductEntity productEntity) {
        return productRepository.save(productEntity);
    }

    @Override
    public ProductEntity getOne(Integer productId) {
        return productRepository.findById(productId).orElseThrow( () -> new RuntimeException("Product with ID: " + productId + " not found"));
    }

    @Override
    public List<ProductEntity> getByType(String type) {
        return productRepository.findBytype(type);
    }

    @Override
    public ProductAndDescriptionVO getProductAndDescription(Integer productId) {
        Optional<ProductEntity> optional =productRepository.findById(productId);
        if (optional.isPresent()) {
            ProductEntity productEntity = optional.get();
            Integer prId = productEntity.getProductId();
            DescriptionVO descriptionVO = descriptionClient.getDescription(prId);
            ProductAndDescriptionVO pdVO = new ProductAndDescriptionVO();
            pdVO.setProductEntity(productEntity);
            pdVO.setDescriptionVO(descriptionVO);
            return pdVO;
        }
        return null;
    }
}
