package com.tej.service;

import com.tej.entities.ProductEntity;
import com.tej.repository.ProductRepository;
import com.tej.vo.ProductAndDescriptionVO;

import java.util.List;

public interface ProductService {

    ProductEntity create(ProductEntity productEntity);
    ProductEntity getOne(Integer productId);
    List<ProductEntity> getByType(String type);
    ProductAndDescriptionVO getProductAndDescription(Integer productId);
}
