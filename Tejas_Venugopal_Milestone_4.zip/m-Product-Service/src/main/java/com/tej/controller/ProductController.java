package com.tej.controller;

import com.tej.entities.ProductEntity;
import com.tej.service.ProductService;
import com.tej.vo.ProductAndDescriptionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public ProductEntity create(@RequestBody ProductEntity productEntity) {
        return productService.create(productEntity);
    }

    @GetMapping("byid/{productId}")
    public ProductEntity getOne(@PathVariable Integer productId) {
        return productService.getOne(productId);
    }

    @GetMapping("bytype/{type}")
    public List<ProductEntity> getByType(@PathVariable String type) {
        return productService.getByType(type);
    }

    @GetMapping("getproductsanddesc/{productId}")
    public ProductAndDescriptionVO getProductsAndDesc(@PathVariable Integer productId) {
        return productService.getProductAndDescription(productId);
    }

}
