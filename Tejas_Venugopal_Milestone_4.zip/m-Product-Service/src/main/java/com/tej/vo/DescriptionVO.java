package com.tej.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DescriptionVO {

    private Integer productId;
    private String productBrand;
    private String productModel;
    private Integer productPrice;

}