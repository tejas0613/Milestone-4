package com.tej.vo;

import com.tej.entities.ProductEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductAndDescriptionVO implements Serializable {

    private ProductEntity productEntity;
    private DescriptionVO descriptionVO;
}
